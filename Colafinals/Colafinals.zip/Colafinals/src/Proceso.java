class Proceso {
    String idProceso;
    long cedula;
    int tiempoCPU;

    public Proceso(String idProceso, long cedula, int tiempoCPU) {
        this.idProceso = idProceso;
        this.cedula = cedula;
        this.tiempoCPU = tiempoCPU;
    }

    public String getIdProceso() {
        return idProceso;
    }

    public void setIdProceso(String idProceso) {
        this.idProceso = idProceso;
    }

    public long getCedula() {
        return cedula;
    }

    public void setCedula(long cedula) {
        this.cedula = cedula;
    }

    public int getTiempoCPU() {
        return tiempoCPU;
    }

    public void setTiempoCPU(int tiempoCPU) {
        this.tiempoCPU = tiempoCPU;
    }

    public String toString() {
        return this.idProceso + ", " + this.cedula + ", " + this.tiempoCPU + "ms";
    }
}
